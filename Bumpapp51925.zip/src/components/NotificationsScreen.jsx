
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Bell, CheckCheck, PackageOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useUser } from "@/lib/user-service"; 
import { useMessages } from "@/lib/message-service";

const NotificationsScreen = () => {
  const { currentUser } = useUser();
  const { messages } = useMessages(); 
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const generateNotifications = () => {
      if (!currentUser || !messages) return [];

      const newNotifications = [];
      
      messages.forEach(msg => {
        if (msg.recipientId === currentUser.id && !msg.read) {
           newNotifications.push({
            id: `msg-${msg.id}`,
            type: "new_message",
            senderName: msg.senderId, 
            content: `You have a new message: "${msg.content.substring(0, 30)}${msg.content.length > 30 ? '...' : ''}"`,
            timestamp: new Date(msg.timestamp),
            read: false,
            link: `/messages/${msg.senderId}`, 
          });
        }
        if (msg.type === 'contact_card' && msg.recipientId === currentUser.id) {
            newNotifications.push({
            id: `contact_card-${msg.id}`,
            type: 'contact_card_received',
            senderName: msg.senderId,
            content: `${msg.sharedContactInfo?.name || 'Someone'} shared their contact card with you.`,
            timestamp: new Date(msg.timestamp),
            read: msg.read, 
            link: `/messages/${msg.senderId}`
            });
        }
      });


      newNotifications.push({
        id: "welcome-notif",
        type: "system",
        content: "Welcome to BUMP! Find amazing people nearby.",
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), 
        read: true,
      });
       newNotifications.push({
        id: "profile-tip-notif",
        type: "tip",
        content: "Tip: Complete your profile to get more BUMPs!",
        timestamp: new Date(Date.now() - 1000 * 60 * 30), 
        read: false,
        link: "/profile/edit"
      });


      newNotifications.sort((a, b) => b.timestamp - a.timestamp);
      setNotifications(newNotifications);
    };

    generateNotifications();
    
  }, [currentUser, messages]);

  const markAsRead = (id) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })));
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case "new_message":
        return <Bell className="h-5 w-5 text-primary" />;
      case "contact_card_received":
        return <Bell className="h-5 w-5 text-green-500" />;
      case "system":
        return <PackageOpen className="h-5 w-5 text-blue-500" />;
      case "tip":
         return <PackageOpen className="h-5 w-5 text-yellow-500" />;
      default:
        return <Bell className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="h-full flex flex-col"
    >
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center justify-between text-2xl">
          <span>Notifications</span>
          {unreadCount > 0 && <Badge variant="destructive">{unreadCount} New</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-0">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <PackageOpen className="w-20 h-20 text-muted-foreground/30 mb-6" />
            <h3 className="text-xl font-semibold text-muted-foreground">All Clear!</h3>
            <p className="text-muted-foreground mt-2">You have no new notifications right now.</p>
          </div>
        ) : (
          <div className="space-y-0">
            {notifications.map((notification, index) => (
              <React.Fragment key={notification.id}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-4 flex items-start space-x-3 hover:bg-muted/50 transition-colors cursor-pointer ${
                    !notification.read ? "bg-primary/5 font-medium" : ""
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className={`mt-1 p-2 rounded-full ${!notification.read ? 'bg-primary/10' : 'bg-muted/80'}`}>
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm ${!notification.read ? "text-foreground" : "text-foreground/80"}`}>
                      {notification.content}
                    </p>
                    <p className={`text-xs ${!notification.read ? "text-primary/80" : "text-muted-foreground"}`}>
                      {notification.timestamp.toLocaleDateString()} {notification.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {!notification.read && (
                    <div className="w-2.5 h-2.5 bg-primary rounded-full self-center shrink-0"></div>
                  )}
                </motion.div>
                {index < notifications.length -1 && <Separator />}
              </React.Fragment>
            ))}
          </div>
        )}
      </CardContent>
      {notifications.length > 0 && unreadCount > 0 && (
        <div className="p-4 border-t">
          <Button onClick={markAllAsRead} className="w-full" variant="outline">
            <CheckCheck className="mr-2 h-4 w-4" /> Mark all as read
          </Button>
        </div>
      )}
    </motion.div>
  );
};

export default NotificationsScreen;

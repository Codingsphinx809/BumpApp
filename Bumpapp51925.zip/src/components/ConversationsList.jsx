
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useUser } from "@/lib/user-service";
import { useMessages } from "@/lib/message-service";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageSquare } from "lucide-react";

const ConversationsList = ({ onSelectConversation }) => {
  const { currentUser, users: allUsers, getUserById } = useUser();
  const { getUserConversations, getConversationMessages } = useMessages();
  const [conversations, setConversations] = useState([]);

  useEffect(() => {
    if (currentUser) {
      const userConversations = getUserConversations(currentUser.id);
      const enrichedConversations = userConversations.map((conv) => {
        const otherUserId = conv.user1Id === currentUser.id ? conv.user2Id : conv.user1Id;
        const otherUser = getUserById(otherUserId);
        const messages = getConversationMessages(conv.user1Id, conv.user2Id);
        const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
        const unreadCount = messages.filter(msg => msg.recipientId === currentUser.id && !msg.read).length;
        
        return { ...conv, otherUser, lastMessage, unreadCount };
      }).filter(conv => conv.otherUser); // Filter out convos where other user might not exist (e.g. deleted)
      
      setConversations(enrichedConversations);
    }
  }, [currentUser, allUsers, getUserConversations, getConversationMessages, getUserById]);


  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  const formatTime = (timestamp) => {
    if (!timestamp) return "";
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    if (diff < 24 * 60 * 60 * 1000 && date.getDate() === now.getDate()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    if (diff < 7 * 24 * 60 * 60 * 1000) {
      return date.toLocaleDateString([], { weekday: 'short' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const truncateMessage = (message, maxLength = 25) => {
    if (!message) return "";
    if (message.type === 'contact_card') return "Sent a contact card";
    if (message.content.length <= maxLength) return message.content;
    return message.content.substring(0, maxLength) + "...";
  };

  if (conversations.length === 0) {
    return (
      <Card className="border-dashed bg-secondary/30">
        <CardContent className="p-8 text-center">
          <MessageSquare className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium">No Messages Yet</h3>
          <p className="text-muted-foreground mt-2">
            Start a conversation with someone nearby. Your chats will appear here.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {conversations.map((conv) => (
        <motion.div
          key={conv.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          whileHover={{ backgroundColor: "hsl(var(--accent))" }}
          className={`rounded-lg transition-colors ${conv.unreadCount > 0 ? "bg-primary/5" : "bg-card"}`}
        >
          <Card 
            className={`hover:shadow-md transition-shadow cursor-pointer border-transparent hover:border-primary/30 ${
              conv.unreadCount > 0 ? "border-primary/50" : ""
            }`}
            onClick={() => onSelectConversation(conv.otherUser)}
          >
            <CardContent className="p-3">
              <div className="flex items-center">
                <div className="relative">
                  <Avatar className="h-12 w-12 mr-3 border-2 border-border">
                    <AvatarImage src={conv.otherUser?.profilePictureUrl} alt={conv.otherUser?.name} />
                    <AvatarFallback className={`${
                      conv.unreadCount > 0 ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary"
                    }`}>
                      {getInitials(conv.otherUser?.name)}
                    </AvatarFallback>
                  </Avatar>
                  {conv.unreadCount > 0 && (
                    <div className="absolute top-0 right-2 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center border-2 border-background">
                      {conv.unreadCount}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <h3 className={`font-medium truncate ${
                      conv.unreadCount > 0 ? "font-semibold text-foreground" : "text-foreground/90"
                    }`}>
                      {conv.otherUser?.name || "Unknown User"}
                    </h3>
                    <span className="text-xs text-muted-foreground ml-2 whitespace-nowrap">
                      {formatTime(conv.lastMessageAt)}
                    </span>
                  </div>
                  <p className={`text-sm truncate ${
                    conv.unreadCount > 0 ? "text-primary font-medium" : "text-muted-foreground"
                  }`}>
                    {conv.lastMessage ? truncateMessage(conv.lastMessage) : "No messages yet"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default ConversationsList;


import React from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, MapPin, Clock, Info } from "lucide-react";

const ChatHeader = ({ user, onBack, onShowProfile, getInitials }) => {
  return (
    <div className="flex items-center p-3 border-b bg-card shadow-sm">
      <Button variant="ghost" size="icon" className="mr-2 text-muted-foreground hover:text-foreground" onClick={onBack}>
        <ArrowLeft className="h-5 w-5" />
      </Button>
      <div className="flex items-center flex-1 cursor-pointer" onClick={onShowProfile}>
        <Avatar className="h-10 w-10 mr-3 border-2 border-transparent hover:border-primary transition-colors">
          <AvatarImage src={user?.profilePictureUrl} alt={user?.name} />
          <AvatarFallback className="bg-primary/10 text-primary">{getInitials(user?.name)}</AvatarFallback>
        </Avatar>
        <div>
          <h3 className="font-semibold">{user?.name || "Chat"}</h3>
          <div className="flex items-center text-xs text-muted-foreground">
            {user?.location ? (
              <> <MapPin className="w-3 h-3 mr-1 text-green-500" /> <span>Nearby</span> </>
            ) : (
              <> <Clock className="w-3 h-3 mr-1" /> <span>Active recently</span> </>
            )}
          </div>
        </div>
      </div>
      <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground" onClick={onShowProfile}>
        <Info className="h-5 w-5" />
      </Button>
    </div>
  );
};

export default ChatHeader;

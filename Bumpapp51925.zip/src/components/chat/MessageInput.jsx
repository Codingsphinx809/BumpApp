
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send } from "lucide-react";

const MessageInput = ({ message, setMessage, handleSendMessage, handleKeyDown }) => {
  return (
    <div className="p-3 border-t bg-card">
      <div className="flex items-center space-x-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Send a BUMP..."
          className="flex-1 rounded-full px-4 py-2 focus:ring-primary focus:ring-2"
        />
        <Button
          size="icon"
          onClick={handleSendMessage}
          disabled={!message.trim()}
          className="rounded-full bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shrink-0 w-10 h-10"
        >
          <Send className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
};

export default MessageInput;

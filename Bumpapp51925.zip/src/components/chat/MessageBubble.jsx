
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserCircle, Mail, Phone, Twitter, Instagram, Linkedin, Globe } from "lucide-react";

const socialIconsSmall = {
  twitter: <Twitter className="w-4 h-4 text-sky-500" />,
  instagram: <Instagram className="w-4 h-4 text-pink-500" />,
  linkedin: <Linkedin className="w-4 h-4 text-blue-700" />,
  website: <Globe className="w-4 h-4 text-gray-500" />,
};

const renderContactCard = (contactInfo) => (
  <Card className="my-2 bg-secondary/50 border-primary/30 max-w-xs w-full">
    <CardHeader className="pb-3 pt-4">
      <CardTitle className="text-sm flex items-center">
        <UserCircle className="w-4 h-4 mr-2 text-primary" />
        {contactInfo.name}'s Contact Card
      </CardTitle>
    </CardHeader>
    <CardContent className="text-xs space-y-1.5 pb-3">
      {contactInfo.email && <p className="flex items-center"><Mail className="w-3 h-3 mr-2 text-muted-foreground" /> {contactInfo.email}</p>}
      {contactInfo.phone && <p className="flex items-center"><Phone className="w-3 h-3 mr-2 text-muted-foreground" /> {contactInfo.phone}</p>}
      {contactInfo.socialMedia && Object.entries(contactInfo.socialMedia).map(([platform, handle]) => 
        handle && (
          <p key={platform} className="flex items-center">
            {React.cloneElement(socialIconsSmall[platform] || <Globe className="w-3 h-3 text-muted-foreground" />, {className: "w-3 h-3 mr-2"})} 
            {handle}
          </p>
        )
      )}
    </CardContent>
  </Card>
);

const MessageBubble = ({ msg, isSent, formatTime, msgIndex }) => {
  return (
    <motion.div
      key={msg.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: msgIndex * 0.05 }}
      className={`flex flex-col ${isSent ? "items-end" : "items-start"}`}
    >
      <div className={`flex flex-col ${isSent ? "items-end" : "items-start"} max-w-[85%]`}>
        {msg.type === 'contact_card' && msg.sharedContactInfo ? (
          renderContactCard(msg.sharedContactInfo)
        ) : (
          <div className={isSent ? "message-bubble-sent shadow-md" : "message-bubble-received shadow-md"}>
            {msg.content}
          </div>
        )}
        <span className="text-xs text-muted-foreground mt-1 px-1">
          {formatTime(msg.timestamp)}
        </span>
      </div>
    </motion.div>
  );
};

export default MessageBubble;

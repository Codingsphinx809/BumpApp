
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUser } from "@/lib/user-service";
import { LogOut, Users, MessageSquare as MessageSquareText, BellDot, Edit, UserCircle2, Compass } from 'lucide-react';
import NearbyUsersBubbleView from "@/components/NearbyUsersBubbleView";
import ConversationsList from "@/components/ConversationsList";
import ChatInterface from "@/components/ChatInterface";
import UserProfile from "@/components/UserProfile";
import NotificationsScreen from "@/components/NotificationsScreen";
import { toast } from "@/components/ui/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";


const MainLayout = ({ onLogout, onNavigateToEditProfile }) => {
  const { currentUser, logout } = useUser();
  const [activeTab, setActiveTab] = useState("nearby"); 
  const [selectedChatUser, setSelectedChatUser] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileUserForModal, setProfileUserForModal] = useState(null);

  const handleStartChat = (user) => {
    setSelectedChatUser(user);
    setActiveTab("chat"); 
  };

  const handleBackFromChat = () => {
    setSelectedChatUser(null);
    setActiveTab("messages"); 
  };

  const handleLogout = () => {
    logout();
    if (onLogout) onLogout();
  };
  
  const handleViewProfile = (user) => { 
    setProfileUserForModal(user);
    setShowProfileModal(true);
  };
  
  const handleBlockUser = (userIdToBlock) => {
    console.log("Block user:", userIdToBlock);
    toast({ title: "User Blocked", description: `This user has been blocked. (Placeholder)`});
    setShowProfileModal(false);
  };

  const handleReportUser = (userIdToReport) => {
    console.log("Report user:", userIdToReport);
    toast({ title: "User Reported", description: `This user has been reported. (Placeholder)`});
    setShowProfileModal(false);
  };
  
  const handleRequestInfo = (userIdRequest) => {
    console.log("Request info from user:", userIdRequest);
    toast({ title: "Info Requested", description: `Information request sent. (Placeholder)`});
  }

  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  const renderContent = () => {
    if (activeTab === "chat" && selectedChatUser) {
      return (
        <ChatInterface 
          user={selectedChatUser} 
          onBack={handleBackFromChat} 
          onNavigateToEdit={onNavigateToEditProfile}
          onViewProfile={handleViewProfile} 
        />
      );
    }
    if (activeTab === "nearby") {
      return <NearbyUsersBubbleView onUserSelect={handleViewProfile} />;
    }
    if (activeTab === "messages") {
      return <ConversationsList onSelectConversation={handleStartChat} />;
    }
    if (activeTab === "notifications") {
      return <NotificationsScreen />;
    }
    return <NearbyUsersBubbleView onUserSelect={handleViewProfile} />; 
  };

  return (
    <div className="flex flex-col h-full bg-background text-foreground">
      <header className="p-4 sticky top-0 z-40 header-glass">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-6">
            <h1 className="text-2xl md:text-3xl font-bold gradient-text">
              BUMP
            </h1>
            <Tabs value={activeTab} onValueChange={(value) => {
              if(value !== 'chat') setSelectedChatUser(null);
              setActiveTab(value);
            }} className="hidden md:block">
              <TabsList className="bg-transparent p-0 gap-1">
                <TabsTrigger value="nearby" className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary data-[state=active]:text-primary data-[state=active]:bg-primary/10 rounded-md transition-all duration-150">
                  <Compass className="w-4 h-4 mr-1.5" /> Nearby
                </TabsTrigger>
                <TabsTrigger value="messages" className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary data-[state=active]:text-primary data-[state=active]:bg-primary/10 rounded-md transition-all duration-150">
                  <MessageSquareText className="w-4 h-4 mr-1.5" /> Messages
                </TabsTrigger>
                 <TabsTrigger value="notifications" className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-primary data-[state=active]:text-primary data-[state=active]:bg-primary/10 rounded-md transition-all duration-150 md:hidden">
                  <BellDot className="w-4 h-4 mr-1.5" /> Activity
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <div className="flex items-center space-x-2 md:space-x-3">
            <Button variant="ghost" size="icon" className="rounded-full hidden md:inline-flex" onClick={() => setActiveTab("notifications")}>
              <BellDot className="h-5 w-5 text-muted-foreground hover:text-primary transition-colors" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar className="h-9 w-9 md:h-10 md:w-10 border-2 border-primary/40 hover:ring-2 hover:ring-primary transition-all">
                    <AvatarImage src={currentUser?.profile_picture_url} alt={currentUser?.name} />
                    <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-primary-foreground text-base">
                      {getInitials(currentUser?.name)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 shadow-xl glass-effect mt-2">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1 p-1">
                    <p className="text-sm font-medium leading-none">{currentUser?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{currentUser?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleViewProfile(currentUser)} className="cursor-pointer py-2 hover:bg-accent/50">
                  <UserCircle2 className="mr-2 h-4 w-4" /> View My Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onNavigateToEditProfile} className="cursor-pointer py-2 hover:bg-accent/50">
                  <Edit className="mr-2 h-4 w-4" /> Edit Profile
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive focus:bg-destructive/10 cursor-pointer py-2">
                  <LogOut className="mr-2 h-4 w-4" /> Log Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
         {/* Mobile Tabs */}
        <div className="mt-3 md:hidden">
          <Tabs value={activeTab} onValueChange={(value) => {
              if(value !== 'chat') setSelectedChatUser(null);
              setActiveTab(value);
            }} className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/30 glass-effect p-1 rounded-lg shadow-inner">
                <TabsTrigger value="nearby" className="py-2.5 text-xs data-[state=active]:bg-card data-[state=active]:text-primary data-[state=active]:shadow-lg rounded-md transition-all duration-200 ease-in-out">
                  <Compass className="w-4 h-4 mr-1" /> Nearby
                </TabsTrigger>
                <TabsTrigger value="messages" className="py-2.5 text-xs data-[state=active]:bg-card data-[state=active]:text-primary data-[state=active]:shadow-lg rounded-md transition-all duration-200 ease-in-out">
                  <MessageSquareText className="w-4 h-4 mr-1" /> Messages
                </TabsTrigger>
                <TabsTrigger value="notifications" className="py-2.5 text-xs data-[state=active]:bg-card data-[state=active]:text-primary data-[state=active]:shadow-lg rounded-md transition-all duration-200 ease-in-out">
                  <BellDot className="w-4 h-4 mr-1" /> Activity
                </TabsTrigger>
              </TabsList>
            </Tabs>
        </div>
      </header>
      
      <main className="flex-1 overflow-hidden p-2 md:p-4 pt-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ type: 'tween', duration: 0.2 }}
            className="h-full"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <AnimatePresence>
        {showProfileModal && profileUserForModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
            onClick={() => { setShowProfileModal(false); setProfileUserForModal(null);}}
          >
            <div className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="glass-effect-darker rounded-xl">
                <UserProfile 
                  user={profileUserForModal} 
                  onClose={() => { setShowProfileModal(false); setProfileUserForModal(null); }}
                  onNavigateToEdit={profileUserForModal.id === currentUser.id ? onNavigateToEditProfile : undefined}
                  onStartChat={profileUserForModal.id !== currentUser.id ? () => {
                    handleStartChat(profileUserForModal);
                    setShowProfileModal(false);
                    setProfileUserForModal(null);
                  } : undefined}
                  onBlockUser={profileUserForModal.id !== currentUser.id ? () => handleBlockUser(profileUserForModal.id) : undefined}
                  onReportUser={profileUserForModal.id !== currentUser.id ? () => handleReportUser(profileUserForModal.id) : undefined}
                  onRequestInfo={profileUserForModal.id !== currentUser.id ? () => handleRequestInfo(profileUserForModal.id) : undefined}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MainLayout;


import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "@/lib/user-service";
import { useLocation } from "@/lib/location-service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { MapPin, Clock, MessageSquare, UserPlus, Eye } from "lucide-react";
import UserProfile from "@/components/UserProfile";

const NearbyUsers = ({ onStartChat, onEditOwnProfile, onNavigateToEdit }) => {
  const { currentUser, getNearbyUsers, updateUserLocation } = useUser();
  const { currentLocation, loading: locationLoading, error: locationError } = useLocation();
  const [nearbyUsers, setNearbyUsers] = useState([]);
  const [selectedUserForProfile, setSelectedUserForProfile] = useState(null);

  useEffect(() => {
    if (currentLocation && currentUser && !locationError) {
      updateUserLocation(currentUser.id, currentLocation);
      const nearby = getNearbyUsers(currentLocation);
      setNearbyUsers(nearby);
    }
  }, [currentLocation, currentUser, locationError, updateUserLocation, getNearbyUsers]);


  const handleViewProfile = (user) => {
    setSelectedUserForProfile(user);
  };

  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  const getTimeAgo = (timestamp) => {
    if (!timestamp) return "Inactive";
    const now = new Date();
    const date = new Date(timestamp);
    const seconds = Math.floor((now - date) / 1000);
    if (seconds < 60) return "Just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  if (locationLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin mb-4"></div>
        <p className="text-muted-foreground">Scanning your surroundings...</p>
        <p className="text-xs text-muted-foreground mt-1">Make sure location services are enabled.</p>
      </div>
    );
  }

  if (locationError) {
     return (
      <div className="text-center p-6 bg-destructive/10 border border-destructive/30 rounded-lg">
        <MapPin className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h3 className="text-lg font-medium text-destructive">Location Error</h3>
        <p className="text-destructive/80 mt-2">
          {locationError}. Please enable location access in your browser/device settings.
        </p>
      </div>
    );
  }


  return (
    <>
      <AnimatePresence>
        {selectedUserForProfile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedUserForProfile(null)} 
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-card rounded-xl shadow-2xl w-full max-w-md overflow-hidden"
              onClick={(e) => e.stopPropagation()} 
            >
              <UserProfile 
                user={selectedUserForProfile} 
                onClose={() => setSelectedUserForProfile(null)}
                onStartChat={() => {
                  onStartChat(selectedUserForProfile);
                  setSelectedUserForProfile(null);
                }}
                onNavigateToEdit={onNavigateToEdit}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">People Nearby (Legacy View)</h2>
          <div className="flex items-center text-sm text-muted-foreground pulse-animation rounded-full px-3 py-1 bg-primary/10">
            <MapPin className="w-4 h-4 mr-1 text-primary" />
            <span>Scanning...</span>
          </div>
        </div>

        {nearbyUsers.length === 0 ? (
          <Card className="border-dashed bg-secondary/30">
            <CardContent className="p-8 text-center">
              <UserPlus className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium">No one in your immediate vicinity yet.</h3>
              <p className="text-muted-foreground mt-2">
                Keep exploring! New connections might be just around the corner.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {nearbyUsers.map((user) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="h-full"
              >
                <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 h-full flex flex-col glass-card">
                  <CardContent className="p-4 flex flex-col flex-grow">
                    <div className="flex items-center mb-3">
                      <Avatar className="h-12 w-12 mr-4 border-2 border-primary/50">
                         <AvatarImage src={user.profilePictureUrl} alt={user.name} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {getInitials(user.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate text-lg">{user.name}</h3>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Clock className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span className="truncate">Active {getTimeAgo(user.lastActive)}</span>
                        </div>
                      </div>
                    </div>
                    
                    {user.occupation && (user.visibilitySettings?.occupation === 'public') && (
                      <p className="text-sm text-muted-foreground truncate mb-1">
                        {user.occupation}
                      </p>
                    )}
                     {user.bio && (user.visibilitySettings?.bio === 'public') && (
                      <p className="text-xs text-muted-foreground/80 line-clamp-2 mb-3 flex-grow">
                        {user.bio}
                      </p>
                    )}
                    {!user.bio && <div className="flex-grow"></div>}


                    <Separator className="my-3" />
                    
                    <div className="flex space-x-2 mt-auto">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => handleViewProfile(user)}
                      >
                        <Eye className="w-4 h-4 mr-2" /> Profile
                      </Button>
                      <Button 
                        size="sm" 
                        className="flex-1 bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white"
                        onClick={() => onStartChat(user)}
                      >
                        <MessageSquare className="w-4 h-4 mr-2" /> Message
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default NearbyUsers;

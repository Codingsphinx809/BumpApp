
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { useUser } from '@/lib/user-service';
import { Mail, LogIn, UserPlus, Github, HelpCircle } from 'lucide-react'; 

const AuthScreen = ({ onLoginSuccess, onSwitchToCreateAccount }) => {
  const [email, setEmail] = useState('');
  const { loginUser } = useUser();

  const handleLogin = (e) => {
    e.preventDefault();
    if (!email) {
      toast({ title: "Email required", description: "Please enter your email to login.", variant: "destructive" });
      return;
    }
    const user = loginUser(email);
    if (user) {
      onLoginSuccess();
    }
  };

  const handleSocialLogin = (provider) => {
    toast({
      title: "Social Login (Coming Soon!)",
      description: `Login with ${provider} is not yet implemented. This is a placeholder.`,
    });
  };
  
  const handleForgotPassword = () => {
    toast({
      title: "Forgot Password (Coming Soon!)",
      description: "Password recovery is not yet implemented. This is a placeholder.",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-md mx-auto p-6 md:p-8 bg-card shadow-xl rounded-lg"
    >
      <div className="text-center mb-8">
        <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 pulse-animation"
          >
           <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
            <path d="M6 12c0-1.7.7-3.2 1.8-4.2"/>
            <path d="M16.2 16.2c1.1-.9 1.8-2.5 1.8-4.2"/>
            <path d="M10.2 7.8c1.1-.9 2.7-1.2 4-.8"/>
            <path d="M4.9 19.1c2.9-2.9 7-3.4 10.5-1.3"/>
            <path d="M13.8 15.2c-1.1.9-2.7 1.2-4 .8"/>
            <path d="M19.1 4.9c-2.9 2.9-7 3.4-10.5 1.3"/>
            <path d="M12 12l0 0"/>
           </svg>
        </motion.div>
        <h1 className="text-3xl font-bold text-foreground">Welcome to BUMP!</h1>
        <p className="text-foreground/80 mt-2 text-lg">Login to connect with people nearby.</p>
      </div>

      <form onSubmit={handleLogin} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="email" className="text-foreground/90">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 bg-background border-border focus:border-primary"
            />
          </div>
        </div>
        <Button type="submit" className="w-full text-lg py-3">
          <LogIn className="mr-2 h-5 w-5" /> Login with Email
        </Button>
      </form>
      
      <div className="text-sm text-right mt-4">
        <Button type="button" variant="link" className="text-primary px-0" onClick={handleForgotPassword}>
          Forgot Password?
        </Button>
      </div>

      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">
            Or continue with
          </span>
        </div>
      </div>

      <div className="space-y-3">
        <Button type="button" variant="outline" className="w-full border-border hover:bg-accent" onClick={() => handleSocialLogin('Google')}>
          <img alt="Google G logo" className="mr-2 h-5 w-5" src="https://images.unsplash.com/photo-1678483789111-3a04c4628bd6" />
          Login with Google
        </Button>
        <Button type="button" variant="outline" className="w-full border-border hover:bg-accent" onClick={() => handleSocialLogin('GitHub')}>
          <Github className="mr-2 h-5 w-5" /> 
          Login with GitHub (Placeholder)
        </Button>
      </div>

      <p className="mt-8 text-center text-md text-foreground/80">
        Don't have an account?{' '}
        <Button type="button" variant="link" className="text-primary font-semibold text-md px-1" onClick={onSwitchToCreateAccount}>
          Create one now <UserPlus className="ml-1 h-4 w-4" />
        </Button>
      </p>
    </motion.div>
  );
};

export default AuthScreen;

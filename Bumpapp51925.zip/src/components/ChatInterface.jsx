
import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "@/lib/user-service";
import { useMessages } from "@/lib/message-service";
import UserProfile from "@/components/UserProfile";
import ChatHeader from "@/components/chat/ChatHeader";
import MessageBubble from "@/components/chat/MessageBubble";
import MessageInput from "@/components/chat/MessageInput";

const ChatInterface = ({ user, onBack, onEditOwnProfile, onNavigateToEdit }) => {
  const { currentUser } = useUser();
  const { 
    sendMessage, 
    getConversationMessages, 
    markMessagesAsRead 
  } = useMessages();
  const [message, setMessage] = useState("");
  const [messagesState, setMessagesState] = useState([]);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    let intervalId;
    if (currentUser && user) {
      const fetchAndSetMessages = () => {
        const conversationMessages = getConversationMessages(currentUser.id, user.id);
        setMessagesState(conversationMessages);
        markMessagesAsRead(user.id, currentUser.id);
      };
      
      fetchAndSetMessages(); // Initial fetch
      intervalId = setInterval(fetchAndSetMessages, 3000); // Poll for new messages
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [currentUser, user, getConversationMessages, markMessagesAsRead]);


  useEffect(() => {
    scrollToBottom();
  }, [messagesState]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = () => {
    if (!message.trim() || !currentUser || !user) return;
    sendMessage(user.id, message, 'text', null);
    setMessage("");
    // Optimistic update can be done here if needed, or rely on polling
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === today.toDateString()) return "Today";
    if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
    return date.toLocaleDateString();
  };

  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  const groupMessagesByDate = () => {
    const groups = [];
    let currentDate = null;
    let currentGroup = [];
    messagesState.forEach((msg) => {
      const messageDate = new Date(msg.timestamp).toDateString();
      if (messageDate !== currentDate) {
        if (currentGroup.length > 0) groups.push({ date: currentDate, messages: currentGroup });
        currentDate = messageDate;
        currentGroup = [msg];
      } else {
        currentGroup.push(msg);
      }
    });
    if (currentGroup.length > 0) groups.push({ date: currentDate, messages: currentGroup });
    return groups;
  };
  
  if (!user || !currentUser) {
      return (
        <div className="flex flex-col h-full items-center justify-center">
          <p>Loading chat...</p>
        </div>
      );
  }

  return (
    <>
      <AnimatePresence>
        {showProfileModal && user && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowProfileModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-card rounded-xl shadow-2xl w-full max-w-md overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <UserProfile 
                user={user} 
                onClose={() => setShowProfileModal(false)}
                onStartChat={() => setShowProfileModal(false)} 
                onEditProfile={user.id === currentUser.id ? onEditOwnProfile : undefined}
                onNavigateToEdit={user.id === currentUser.id ? onNavigateToEdit : undefined}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col h-full">
        <ChatHeader user={user} onBack={onBack} onShowProfile={() => setShowProfileModal(true)} getInitials={getInitials}/>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-secondary/20 scrollbar-thin">
          {groupMessagesByDate().map((group, groupIndex) => (
            <div key={group.date || groupIndex} className="space-y-2">
              <div className="flex justify-center my-3">
                <div className="bg-background px-3 py-1 rounded-full text-xs text-muted-foreground shadow-sm border">
                  {formatDate(new Date(group.date))}
                </div>
              </div>
              {group.messages.map((msg, msgIndex) => (
                <MessageBubble 
                  key={msg.id}
                  msg={msg} 
                  isSent={msg.senderId === currentUser?.id} 
                  formatTime={formatTime}
                  msgIndex={msgIndex}
                />
              ))}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        <MessageInput 
            message={message} 
            setMessage={setMessage} 
            handleSendMessage={handleSendMessage} 
            handleKeyDown={handleKeyDown}
        />
      </div>
    </>
  );
};

export default ChatInterface;

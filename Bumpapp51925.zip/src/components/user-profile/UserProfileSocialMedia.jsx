
import React from "react";
import UserProfileSection from "./UserProfileSection";
import { Globe, Twitter, Instagram, Linkedin, EyeOff, Users, Lock } from "lucide-react";


const VisibilityIcon = ({ level }) => {
  if (level === 'public') return <Globe className="w-3 h-3 ml-1.5 opacity-60" title="Public" />;
  if (level === 'connections') return <Users className="w-3 h-3 ml-1.5 opacity-60" title="Connections Only" />;
  if (level === 'private') return <Lock className="w-3 h-3 ml-1.5 opacity-60" title="Private" />;
  return null;
};

const UserProfileSocialMedia = ({ user, isOwnProfile, canView }) => {
  if (!user.social_media_handles && !isOwnProfile) return null;
  
  const socialIcons = {
    twitter: <Twitter className="w-5 h-5 text-sky-500" />,
    instagram: <Instagram className="w-5 h-5 text-pink-500" />,
    linkedin: <Linkedin className="w-5 h-5 text-blue-700" />,
    website: <Globe className="w-5 h-5 text-gray-500" />,
  };

  const links = Object.entries(user.social_media_handles || {})
    .filter(([_, handle]) => handle)
    .map(([platform, handle]) => {
      if (!(isOwnProfile || canView('social_media_handles'))) return null;

      const url = platform === 'website' || handle.startsWith('http') ? handle : 
                  platform === 'twitter' ? `https://twitter.com/${handle}` :
                  platform === 'instagram' ? `https://instagram.com/${handle}` :
                  platform === 'linkedin' ? handle.startsWith('http') ? handle : `https://linkedin.com/in/${handle}` : '#';
      return (
        <a key={platform} href={url} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 hover:text-primary transition-colors text-sm">
          {socialIcons[platform] || <Globe className="w-5 h-5" />}
          <span className="truncate">{handle.startsWith('http') ? new URL(handle).hostname : handle}</span>
        </a>
      );
    }).filter(Boolean);

  const hasAnySocialMedia = user.social_media_handles && Object.values(user.social_media_handles).some(val => val);
  const showSection = links.length > 0 || (isOwnProfile && !hasAnySocialMedia);
  const showPrivateMessage = links.length === 0 && !isOwnProfile && hasAnySocialMedia && !canView('social_media_handles');
  const showNotSetMessage = links.length === 0 && (isOwnProfile || canView('social_media_handles')) && !hasAnySocialMedia;


  return (
    <UserProfileSection title="Social Media" condition={showSection || showPrivateMessage}>
        {isOwnProfile && <div className="flex items-center mb-1 text-xs text-muted-foreground">Overall Social Media Visibility: <VisibilityIcon level={user.visibility_settings?.social_media_handles} /></div>}
       {links.length > 0 && <div className="space-y-2">{links}</div>}
       {showPrivateMessage && (
          <p className="text-sm text-muted-foreground italic flex items-center">
            <EyeOff className="w-4 h-4 mr-2"/> Social media links are private or for connections only.
          </p>
        )}
       {showNotSetMessage && <p className="text-sm text-muted-foreground italic">No social media links provided.</p>}
    </UserProfileSection>
  );
};

export default UserProfileSocialMedia;


import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
    Settings, MessageSquare, Send, Ban, ShieldAlert, HelpCircle, PhoneForwarded
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useUser } from "@/lib/user-service";
import { useMessages } from "@/lib/message-service";
import { toast } from "@/components/ui/use-toast";


const UserProfileActions = ({ 
    isOwnProfile, 
    onNavigateToEdit, 
    onStartChat, 
    handleShareContactCard, 
    onBlockUser, 
    onReportUser, 
    onRequestInfo, 
    user 
}) => {
  const { currentUser } = useUser();
  const { sendMessage } = useMessages();
  const [showSharePhoneDialog, setShowSharePhoneDialog] = useState(false);

  const handleSharePhoneNumber = () => {
    if (!currentUser || !user || isOwnProfile || !currentUser.phone_number) {
      toast({
        title: "Cannot Share Phone Number",
        description: "You don't have a phone number set in your profile, or you are trying to share with yourself.",
        variant: "destructive",
      });
      return;
    }
    sendMessage(user.id, `${currentUser.name} shared their phone number with you: ${currentUser.phone_number}`, 'text', null);
    toast({ title: "Phone Number Shared!", description: `Your phone number has been sent to ${user.name}.` });
    setShowSharePhoneDialog(false);
  };

  if (isOwnProfile) {
    return (
      <Button size="lg" className="w-full text-md py-3" onClick={onNavigateToEdit}>
        <Settings className="w-5 h-5 mr-2" /> Edit Profile
      </Button>
    );
  }
  return (
    <div className="space-y-2">
      <div className="flex space-x-2">
        <Button size="lg" className="flex-1 text-md py-3" onClick={() => onStartChat && onStartChat(user)}>
          <MessageSquare className="w-5 h-5 mr-2" /> Message
        </Button>
        <Button size="lg" variant="outline" className="flex-1 text-md py-3" onClick={handleShareContactCard}>
          <Send className="w-5 h-5 mr-2" /> Share Card
        </Button>
      </div>
      <div className="flex space-x-2">
        <Button variant="outline" className="flex-1" onClick={() => onBlockUser && onBlockUser(user.id)}>
          <Ban className="w-4 h-4 mr-2 text-destructive" /> Block
        </Button>
        <Button variant="outline" className="flex-1" onClick={() => onReportUser && onReportUser(user.id)}>
          <ShieldAlert className="w-4 h-4 mr-2" /> Report
        </Button>
        <Button variant="outline" className="flex-1" onClick={() => onRequestInfo && onRequestInfo(user.id)}>
          <HelpCircle className="w-4 h-4 mr-2" /> Request Info
        </Button>
      </div>
       {currentUser?.phone_number && user.id !== currentUser?.id && (
        <AlertDialog open={showSharePhoneDialog} onOpenChange={setShowSharePhoneDialog}>
          <AlertDialogTrigger asChild>
            <Button variant="outline" className="w-full mt-2 text-primary border-primary hover:bg-primary/10 hover:text-primary">
              <PhoneForwarded className="w-4 h-4 mr-2" /> Share My Phone Number
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Share Your Phone Number?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to share your phone number ({currentUser.phone_number}) directly with {user.name}? This will send them a message containing your number.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleSharePhoneNumber} className="bg-primary hover:bg-primary/90">Share Now</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
};

export default UserProfileActions;


import React from "react";
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Settings, MapPin, Globe, Users, Lock } from "lucide-react";

const VisibilityIcon = ({ level }) => {
  if (level === 'public') return <Globe className="w-3 h-3 ml-1.5 opacity-70" title="Public" />;
  if (level === 'connections') return <Users className="w-3 h-3 ml-1.5 opacity-70" title="Connections Only" />;
  if (level === 'private') return <Lock className="w-3 h-3 ml-1.5 opacity-70" title="Private" />;
  return null;
};

const UserProfileHeader = ({ user, isOwnProfile, getInitials, formatDistance, onEditProfile, onNavigateToEdit, canView }) => {
  
  const nameVisible = isOwnProfile || canView('name');
  const profilePictureVisible = isOwnProfile || canView('profile_picture_url');
  const occupationVisible = isOwnProfile || canView('occupation');
  const cityVisible = isOwnProfile || canView('city');

  return (
    <div className="bg-gradient-to-br from-primary/10 via-transparent to-secondary/10 p-6 pt-10 text-center shrink-0 border-b">
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.3 }}>
        {profilePictureVisible ? (
          <Avatar className="h-28 w-28 mx-auto border-4 border-background shadow-xl">
            <AvatarImage src={user.profile_picture_url} alt={user.name} />
            <AvatarFallback className="text-4xl bg-primary text-primary-foreground">{getInitials(user.name)}</AvatarFallback>
          </Avatar>
        ) : (
           <Avatar className="h-28 w-28 mx-auto border-4 border-background shadow-xl">
            <AvatarFallback className="text-4xl bg-muted text-muted-foreground">{getInitials("?")}</AvatarFallback>
          </Avatar>
        )}
      </motion.div>

      {nameVisible ? (
        <h2 className="text-3xl font-bold mt-4 flex items-center justify-center">
            {user.name}
            {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.name} />}
        </h2>
      ) : (
        <h2 className="text-3xl font-bold mt-4 text-muted-foreground italic">Name Private</h2>
      )}

      {occupationVisible && user.occupation && (
        <p className="text-muted-foreground text-lg flex items-center justify-center">
            {user.occupation}
            {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.occupation} />}
        </p>
      )}
      
      {cityVisible && user.city && (
         <p className="text-muted-foreground text-sm flex items-center justify-center">
            <MapPin className="w-3.5 h-3.5 mr-1"/> {user.city}
            {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.city} />}
        </p>
      )}

      {!isOwnProfile && user.location && (
        <div className="flex items-center justify-center mt-2 text-md text-primary font-medium">
          <MapPin className="w-5 h-5 mr-1" />
          <span>{formatDistance()}</span>
        </div>
      )}
      {isOwnProfile && onEditProfile && (
        <Button variant="outline" size="sm" className="mt-3" onClick={onEditProfile}>
          <Settings className="w-4 h-4 mr-2" /> Edit Your Profile
        </Button>
      )}
       {isOwnProfile && onNavigateToEdit && (
        <Button variant="outline" size="sm" className="mt-3" onClick={onNavigateToEdit}>
          <Settings className="w-4 h-4 mr-2" /> Edit Profile
        </Button>
      )}
    </div>
  );
};

export default UserProfileHeader;


import React from "react";
import UserProfileField from "./UserProfileField";
import UserProfileSection from "./UserProfileSection";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MessageCircle, EyeOff, Globe, Users, Lock } from "lucide-react";


const VisibilityIcon = ({ level }) => {
  if (level === 'public') return <Globe className="w-3 h-3 ml-1.5 opacity-60" title="Public" />;
  if (level === 'connections') return <Users className="w-3 h-3 ml-1.5 opacity-60" title="Connections Only" />;
  if (level === 'private') return <Lock className="w-3 h-3 ml-1.5 opacity-60" title="Private" />;
  return null;
};

const UserProfileContactInfo = ({ user, isOwnProfile, canView, handleTextUser }) => {
  const emailValue = user.email;
  const phoneValue = user.phone_number;

  const emailField = UserProfileField({ 
    fieldName: 'email', 
    icon: <Mail/>, 
    value: emailValue, 
    isOwnProfile, 
    canView,
    children: isOwnProfile && <VisibilityIcon level={user.visibility_settings?.email} />
  });

  const phoneField = UserProfileField({ 
    fieldName: 'phone_number', 
    icon: <Phone/>, 
    value: phoneValue, 
    isOwnProfile, 
    canView,
    children: (
      <>
        {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.phone_number} />}
        {phoneValue && (isOwnProfile || canView('phone_number')) && !isOwnProfile && (
          <Button variant="link" size="sm" className="p-0 h-auto text-primary flex items-center ml-2" onClick={() => handleTextUser(phoneValue)}>
            <MessageCircle className="w-3 h-3 mr-1" /> Text
          </Button>
        )}
      </>
    )
  });
  
  const showSection = emailField || phoneField;
  
  const showPrivateMessage = !isOwnProfile && 
    ((emailValue && !canView('email')) || (phoneValue && !canView('phone_number')));

  return (
    <UserProfileSection title="Contact Info" condition={showSection || showPrivateMessage}>
      <div className="space-y-2">
        {emailField}
        {phoneField}
        {showPrivateMessage && !showSection && ( 
          <p className="text-sm text-muted-foreground italic flex items-center">
            <EyeOff className="w-4 h-4 mr-2"/> Contact details are private or for connections only.
          </p>
        )}
      </div>
    </UserProfileSection>
  );
};

export default UserProfileContactInfo;


import React from "react";

const UserProfileSection = ({ title, children, condition = true }) => {
  if (!condition || !React.Children.toArray(children).some(child => child !== null && child !== false && (typeof child !== 'object' || Object.keys(child).length > 0))) {
    return null;
  }
  return (
    <div>
      <h3 className="text-sm font-semibold text-muted-foreground mb-1 uppercase tracking-wider">{title}</h3>
      {children}
    </div>
  );
};

export default UserProfileSection;

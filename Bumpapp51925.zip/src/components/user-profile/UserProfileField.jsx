
import React from "react";

const UserProfileField = ({ fieldName, icon, value, isOwnProfile, canView, children }) => {
  if (isOwnProfile || canView(fieldName)) {
    if (value || (children && React.Children.count(children) > 0)) {
      return (
        <div className="flex items-center text-sm">
          {icon && React.cloneElement(icon, { className: "w-4 h-4 mr-3 text-muted-foreground flex-shrink-0" })}
          {value && <span>{value}</span>}
          {children}
        </div>
      );
    } else if (isOwnProfile) {
      return (
        <div className="flex items-center text-sm text-muted-foreground italic">
          {icon && React.cloneElement(icon, { className: "w-4 h-4 mr-3 flex-shrink-0" })}
          <span>Not specified</span>
        </div>
      );
    }
  }
  return null;
};

export default UserProfileField;

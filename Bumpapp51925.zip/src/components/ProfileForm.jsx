
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useUser } from '@/lib/user-service';
import { toast } from '@/components/ui/use-toast';
import { Camera, Save, XCircle, User, Mail, Briefcase, Heart, Link as LinkIcon, ShieldCheck, Globe, Users, Lock, Phone, MapPin as MapPinIcon } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { defaultVisibilitySettings, defaultSocialMediaHandles } from "@/lib/user-data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';


const ProfileFormField = ({ field, formData, handleChange, getInitials, previewImage, triggerFileInput, fileInputRef, handleImageUpload }) => {
  if (field.type === 'image_upload') {
    return (
      <div className="flex flex-col items-center space-y-4 col-span-1 md:col-span-2">
        <Avatar className="w-36 h-36 border-4 border-primary/20 shadow-lg ring-2 ring-primary/30">
          <AvatarImage src={previewImage || formData.profilePictureUrl} alt={formData.name} />
          <AvatarFallback className="text-5xl bg-primary/10 text-primary">{getInitials(formData.name)}</AvatarFallback>
        </Avatar>
        <Button type="button" variant="outline" onClick={triggerFileInput} className="gap-2">
          <Camera /> Upload Picture
        </Button>
        <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      <Label htmlFor={field.key} className="flex items-center text-sm font-medium text-foreground/90">
        {field.icon && React.cloneElement(field.icon, { className: "w-4 h-4 mr-2 text-primary/80"})} 
        {field.label} {field.required && <span className="text-destructive ml-1">*</span>}
      </Label>
      {field.type === 'textarea' ? (
        <Textarea id={field.key} name={field.key} value={formData[field.key] || ''} onChange={handleChange} placeholder={field.placeholder} rows={4} className="resize-none"/>
      ) : (
        <Input id={field.key} name={field.key} type={field.type} value={formData[field.key] || ''} onChange={handleChange} placeholder={field.placeholder} required={field.required} />
      )}
    </div>
  );
};

const SocialMediaFieldset = ({ socialMediaFieldsConfig, formData, handleSocialMediaChange }) => (
  <Card className="col-span-1 md:col-span-2">
    <CardHeader>
      <CardTitle className="text-xl flex items-center gap-2"><LinkIcon />Social Media Links</CardTitle>
      <CardDescription>Connect your other profiles (optional).</CardDescription>
    </CardHeader>
    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
      {socialMediaFieldsConfig.map(socialField => (
        <div key={socialField.key} className="space-y-1.5">
          <Label htmlFor={socialField.key} className="flex items-center text-xs text-muted-foreground">
            <LinkIcon className="w-3 h-3 mr-1.5"/>{socialField.label}
          </Label>
          <Input id={socialField.key} name={socialField.key} type={socialField.type || 'text'} value={formData.social_media_handles[socialField.key] || ''} onChange={handleSocialMediaChange} placeholder={socialField.placeholder} />
        </div>
      ))}
    </CardContent>
  </Card>
);

const VisibilitySettingsFieldset = ({ profileFieldsConfig, socialMediaFieldsConfig, formData, handleVisibilityChange, visibilityOptions }) => (
  <Card className="col-span-1 md:col-span-2">
    <CardHeader>
      <CardTitle className="text-xl flex items-center gap-2"><ShieldCheck />Visibility Settings</CardTitle>
      <CardDescription>Control who sees your information.</CardDescription>
    </CardHeader>
    <CardContent className="space-y-5">
      {[...profileFieldsConfig, {key: 'social_media_handles', label: 'Social Media Links', icon: <LinkIcon/>, visibilityKey: 'social_media_handles'}]
        .filter(f => f.visibilityKey)
        .map(field => (
        <div key={`visibility-${field.visibilityKey}`} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-4 p-3 border rounded-lg bg-background/50">
          <Label htmlFor={`visibility-select-${field.visibilityKey}`} className="flex items-center text-sm font-medium text-foreground/90 whitespace-nowrap">
            {field.icon && React.cloneElement(field.icon, {className: "w-4 h-4 mr-2 text-primary/80"})}
            {field.label}
          </Label>
          <Select
            value={formData.visibility_settings[field.visibilityKey] || 'private'}
            onValueChange={(value) => handleVisibilityChange(field.visibilityKey, value)}
          >
            <SelectTrigger className="w-full sm:w-[220px]">
              <SelectValue placeholder="Select visibility" />
            </SelectTrigger>
            <SelectContent>
              {visibilityOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">{option.icon} {option.label}</div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      ))}
      <p className="text-xs text-muted-foreground pt-2 text-center">Note: Your Name and Profile Picture are essential for BUMP and are always public for discoverability.</p>
    </CardContent>
  </Card>
);


const ProfileForm = ({ onComplete, isEditMode = true }) => {
  const { currentUser, createUser, updateUser } = useUser();
  const [formData, setFormData] = useState({
    name: '', email: '', profilePictureUrl: '', bio: '', occupation: '', interests: '',
    phone_number: '', city: '',
    social_media_handles: { ...defaultSocialMediaHandles },
    visibility_settings: { ...defaultVisibilitySettings },
  });
  const [previewImage, setPreviewImage] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (isEditMode && currentUser) {
      setFormData({
        name: currentUser.name || '', email: currentUser.email || '',
        profilePictureUrl: currentUser.profile_picture_url || '',
        bio: currentUser.bio || '', occupation: currentUser.occupation || '',
        interests: currentUser.interests || '', phone_number: currentUser.phone_number || '',
        city: currentUser.city || '',
        social_media_handles: currentUser.social_media_handles || { ...defaultSocialMediaHandles },
        visibility_settings: { ...defaultVisibilitySettings, ...currentUser.visibility_settings }
      });
      setPreviewImage(currentUser.profile_picture_url || null);
    } else if (!isEditMode) {
      setFormData(prev => ({ ...prev, visibility_settings: { ...defaultVisibilitySettings } }));
    }
  }, [currentUser, isEditMode]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSocialMediaChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, social_media_handles: { ...prev.social_media_handles, [name]: value }}));
  };
  
  const handleVisibilityChange = (field, value) => {
    setFormData(prev => ({ ...prev, visibility_settings: { ...prev.visibility_settings, [field]: value }}));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
        setFormData((prev) => ({ ...prev, profilePictureUrl: reader.result }));
        toast({ title: "Image Selected", description: "Profile picture updated. Save changes to apply."});
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => fileInputRef.current?.click();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      toast({ title: 'Missing Information', description: 'Name and email are required.', variant: 'destructive' });
      return;
    }
    const profileData = { ...formData };
    if (isEditMode && currentUser) await updateUser(currentUser.id, profileData);
    else await createUser(profileData);
    onComplete();
  };

  const getInitials = (name) => (name ? name.split(' ').map(n => n[0]).join('').toUpperCase() : <User />);

  const visibilityOptions = [
    { value: 'public', label: 'Public', icon: <Globe className="w-4 h-4"/> },
    { value: 'connections', label: 'Connections Only', icon: <Users className="w-4 h-4"/> },
    { value: 'private', label: 'Only Me', icon: <Lock className="w-4 h-4"/> },
  ];

  const profileFieldsConfig = [
    { key: 'name', label: 'Full Name', icon: <User/>, type: 'text', required: true, visibilityKey: 'name' },
    { key: 'profile_picture_url', label: 'Profile Picture', type: 'image_upload', visibilityKey: 'profile_picture_url' },
    { key: 'email', label: 'Email Address', icon: <Mail/>, type: 'email', required: true, visibilityKey: 'email'},
    { key: 'phone_number', label: 'Phone Number', icon: <Phone/>, type: 'tel', placeholder: 'e.g., 555-123-4567', visibilityKey: 'phone_number' },
    { key: 'city', label: 'City', icon: <MapPinIcon/>, type: 'text', placeholder: 'e.g., San Francisco', visibilityKey: 'city' },
    { key: 'occupation', label: 'Occupation', icon: <Briefcase/>, type: 'text', placeholder: 'e.g., Software Developer', visibilityKey: 'occupation' },
    { key: 'bio', label: 'Your Bio', icon: <User/>, type: 'textarea', placeholder: 'Tell us about yourself...', visibilityKey: 'bio' },
    { key: 'interests', label: 'Interests (comma-separated)', icon: <Heart/>, type: 'text', placeholder: 'e.g., Hiking, Coding, Art', visibilityKey: 'interests' },
  ];

  const socialMediaFieldsConfig = [
    { key: 'twitter', label: 'Twitter', placeholder: 'yourhandle' }, { key: 'instagram', label: 'Instagram', placeholder: 'yourhandle' },
    { key: 'linkedin', label: 'LinkedIn', placeholder: 'yourprofile' }, { key: 'website', label: 'Website', type: 'url', placeholder: 'https://your.site' },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">{isEditMode ? 'Edit Your Profile' : 'Create Your BUMP Profile'}</CardTitle>
            <CardDescription>Fill in your details to connect with others.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            {profileFieldsConfig.map(field => (
              <ProfileFormField key={field.key} field={field} formData={formData} handleChange={handleChange} getInitials={getInitials} previewImage={previewImage} triggerFileInput={triggerFileInput} fileInputRef={fileInputRef} handleImageUpload={handleImageUpload} />
            ))}
          </CardContent>
        </Card>
        
        <SocialMediaFieldset socialMediaFieldsConfig={socialMediaFieldsConfig} formData={formData} handleSocialMediaChange={handleSocialMediaChange} />
        <VisibilitySettingsFieldset profileFieldsConfig={profileFieldsConfig} socialMediaFieldsConfig={socialMediaFieldsConfig} formData={formData} handleVisibilityChange={handleVisibilityChange} visibilityOptions={visibilityOptions} />

        <div className="flex flex-col sm:flex-row sm:justify-end space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
          <Button type="button" variant="outline" size="lg" onClick={onComplete} className="w-full sm:w-auto gap-2">
            <XCircle /> {isEditMode ? 'Cancel' : 'Back to Login'}
          </Button>
          <Button type="submit" size="lg" className="w-full sm:w-auto gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90">
            <Save /> {isEditMode ? 'Save Changes' : 'Create Profile'}
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default ProfileForm;


import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Info, Globe, Users, Lock } from "lucide-react";
import { useLocation } from "@/lib/location-service";
import { useUser } from "@/lib/user-service";
import { useMessages } from "@/lib/message-service";
import { toast } from "@/components/ui/use-toast";

import UserProfileHeader from "./user-profile/UserProfileHeader";
import UserProfileSection from "./user-profile/UserProfileSection";
import UserProfileContactInfo from "./user-profile/UserProfileContactInfo";
import UserProfileSocialMedia from "./user-profile/UserProfileSocialMedia";
import UserProfileActions from "./user-profile/UserProfileActions";

const VisibilityIcon = ({ level }) => {
  const iconProps = { className: "w-3.5 h-3.5 ml-1.5 opacity-70" };
  if (level === 'public') return <Globe {...iconProps} title="Public" />;
  if (level === 'connections') return <Users {...iconProps} title="Connections Only" />;
  if (level === 'private') return <Lock {...iconProps} title="Private" />;
  return null;
};

const UserProfile = ({ 
    user, 
    onClose, 
    onStartChat, 
    onBlockUser,
    onReportUser,
    onRequestInfo,
    onNavigateToEdit,
}) => {
  const { currentLocation, calculateDistance } = useLocation();
  const { currentUser } = useUser();
  const { sendMessage } = useMessages();

  if (!user) return null;
  const isOwnProfile = currentUser && user && currentUser.id === user.id;

  const getInitials = (name) => (name ? name.split(" ").map((n) => n[0]).join("").toUpperCase() : "?");

  const formatDistance = () => {
    if (!currentLocation || !user.location || !user.location.latitude || !user.location.longitude) return "Location unknown";
    const distance = calculateDistance(
        currentLocation.latitude, currentLocation.longitude,
        user.location.latitude, user.location.longitude
    );
    if (distance === null) return "Location unknown";
    if (distance < 0.1) return "Very close";
    if (distance < 1) return `${Math.round(distance * 1000)}m away`;
    return `${distance.toFixed(1)} km away`;
  };

  const canViewField = (fieldName) => {
    if (isOwnProfile) return true;
    if (!user.visibility_settings) return false; 
    
    const setting = user.visibility_settings[fieldName];
    if (setting === 'public') return true;
    if (setting === 'connections') {
      return false; 
    }
    return false; 
  };
  
  const hasAnyPublicInfo = () => {
    if (!user || !user.visibility_settings) return false;
    const { visibility_settings } = user;
    const fieldsToCheck = ['bio', 'interests', 'email', 'phone_number', 'social_media_handles', 'occupation', 'city'];
    return fieldsToCheck.some(key => 
        visibility_settings[key] === 'public' && (
            key === 'social_media_handles' ? 
            user[key] && Object.values(user[key]).some(v => v) : 
            user[key]
        )
    );
  };

  const handleShareContactCard = () => {
    if (!currentUser || !user || isOwnProfile) return;
    const contactInfoToShare = { name: currentUser.name };
    if (currentUser.visibility_settings?.email === 'public' && currentUser.email) contactInfoToShare.email = currentUser.email;
    if (currentUser.visibility_settings?.phone_number === 'public' && currentUser.phone_number) contactInfoToShare.phone_number = currentUser.phone_number;
    if (currentUser.visibility_settings?.social_media_handles === 'public' && currentUser.social_media_handles) contactInfoToShare.social_media_handles = currentUser.social_media_handles;
    
    const filteredContactInfo = Object.fromEntries(
      Object.entries(contactInfoToShare).filter(([key, value]) => 
        key === 'social_media_handles' ? value && Object.values(value).some(v => v) : value
      )
    );

    if (Object.keys(filteredContactInfo).length <= 1 && filteredContactInfo.name) {
       toast({ title: "Nothing to Share", description: "Make some contact details public to share your card.", variant: "destructive"});
       return;
    }
    sendMessage(user.id, `${currentUser.name} shared their contact card.`, 'contact_card', filteredContactInfo);
    toast({ title: "Contact Card Sent!", description: `Sent to ${user.name}.` });
    if (onClose) onClose();
  };

  const handleTextUser = (phoneNumber) => {
    if (phoneNumber) {
      window.location.href = `sms:${phoneNumber}`;
      toast({ title: "Opening Messages", description: `Attempting to open SMS app for ${phoneNumber}.` });
    } else {
      toast({ title: "No Phone Number", description: "This user has not shared a phone number.", variant: "destructive" });
    }
  };

  const bioVisible = canViewField('bio') && user.bio;
  const interestsVisible = canViewField('interests') && user.interests && user.interests.length > 0;
  const contactInfoHasContent = (user.email && canViewField('email')) || (user.phone_number && canViewField('phone_number'));
  const socialMediaHasContent = user.social_media_handles && Object.values(user.social_media_handles).some(s => s) && canViewField('social_media_handles');

  return (
    <motion.div 
      className="relative max-h-[95vh] md:max-h-[90vh] flex flex-col rounded-xl overflow-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="absolute top-3 right-3 z-20">
        <Button variant="ghost" size="icon" className="rounded-full bg-black/20 hover:bg-black/40 text-white" onClick={onClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>

      <UserProfileHeader 
        user={user} 
        isOwnProfile={isOwnProfile} 
        getInitials={getInitials} 
        formatDistance={formatDistance} 
        onNavigateToEdit={isOwnProfile ? onNavigateToEdit : undefined}
        canView={canViewField}
      />

      <div className="p-5 md:p-6 overflow-y-auto flex-1 space-y-5 scrollbar-thin">
        <UserProfileSection title="About Me" condition={bioVisible}>
          <div className="flex items-start text-foreground/90">
            <p className="text-base leading-relaxed whitespace-pre-wrap flex-grow">{user.bio}</p>
            {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.bio} />}
          </div>
        </UserProfileSection>

        <UserProfileSection title="My Interests" condition={interestsVisible}>
          <div className="flex items-start text-foreground/90">
            <p className="text-base flex-grow">{user.interests?.split(',').map(interest => interest.trim()).join('  •  ')}</p>
            {isOwnProfile && <VisibilityIcon level={user.visibility_settings?.interests} />}
          </div>
        </UserProfileSection>
        
        {(bioVisible || interestsVisible) && (contactInfoHasContent || socialMediaHasContent) && <Separator className="my-3"/>}

        <UserProfileContactInfo user={user} isOwnProfile={isOwnProfile} canView={canViewField} handleTextUser={handleTextUser}/>
        
        {contactInfoHasContent && socialMediaHasContent && <Separator className="my-3"/>}
        
        <UserProfileSocialMedia user={user} isOwnProfile={isOwnProfile} canView={canViewField} />
        
        {!isOwnProfile && !hasAnyPublicInfo() && !bioVisible && !interestsVisible && (
            <Card className="mt-4 bg-accent/20 border-accent/40">
                <CardHeader>
                    <CardTitle className="text-lg flex items-center"><Info className="w-5 h-5 mr-2 text-primary"/>Profile Information</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                    <p className="text-sm text-foreground/80">
                        This user's profile is mostly private. Send a message or share your contact card to connect and see more.
                    </p>
                </CardContent>
            </Card>
        )}
      </div>

      <div className="p-4 border-t bg-background/50 backdrop-blur-sm shrink-0">
        <UserProfileActions 
          isOwnProfile={isOwnProfile} 
          onNavigateToEdit={onNavigateToEdit}
          onStartChat={onStartChat} 
          handleShareContactCard={handleShareContactCard} 
          onBlockUser={onBlockUser} 
          onReportUser={onReportUser} 
          onRequestInfo={onRequestInfo}
          user={user}
        />
      </div>
    </motion.div>
  );
};

export default UserProfile;

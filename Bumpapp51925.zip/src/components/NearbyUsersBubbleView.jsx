
import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useUser } from "@/lib/user-service";
import { useLocation } from "@/lib/location-service";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, Info, UserPlus, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const NearbyUsersBubbleView = ({ onUserSelect }) => {
  const { currentUser, getNearbyUsers, updateUserLocation } = useUser();
  const { currentLocation, loading: locationLoading, error: locationError, usingFallback } = useLocation();
  const [internalNearbyUsers, setInternalNearbyUsers] = useState([]);
  const containerRef = useRef(null);
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const scrollContainerRef = useRef(null);

  const ORBITING_USERS_LIMIT = 5;
  const CENTRAL_USER_SIZE_BASE = 80; 
  const ORBITING_BUBBLE_SIZE_BASE = 60;
  const SCROLL_BUBBLE_SIZE = 50;
  const ORBIT_RADIUS_FACTOR = 0.30; 

  const centralUserSize = Math.min(containerSize.width, containerSize.height) * 0.20 < CENTRAL_USER_SIZE_BASE ? Math.min(containerSize.width, containerSize.height) * 0.20 : CENTRAL_USER_SIZE_BASE;
  const orbitingBubbleSize = Math.min(containerSize.width, containerSize.height) * 0.15 < ORBITING_BUBBLE_SIZE_BASE ? Math.min(containerSize.width, containerSize.height) * 0.15 : ORBITING_BUBBLE_SIZE_BASE;


  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        setContainerSize({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  useEffect(() => {
    let intervalId;
    if (currentLocation && currentUser) {
      updateUserLocation(currentUser.id, currentLocation);
      const fetchAndSetNearbyUsers = () => {
        const nearby = getNearbyUsers(currentLocation, usingFallback ? 5000 : 20); // Increased radius for fallback
        setInternalNearbyUsers(nearby.sort((a, b) => (a.distance || Infinity) - (b.distance || Infinity)));
      };
      fetchAndSetNearbyUsers();
      intervalId = setInterval(fetchAndSetNearbyUsers, 5000); 
    }
    return () => clearInterval(intervalId);
  }, [currentLocation, currentUser, locationError, updateUserLocation, getNearbyUsers, usingFallback]);


  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  const { orbitingUsers, scrollableUsers } = useMemo(() => {
    return {
      orbitingUsers: internalNearbyUsers.slice(0, ORBITING_USERS_LIMIT),
      scrollableUsers: internalNearbyUsers.slice(ORBITING_USERS_LIMIT),
    };
  }, [internalNearbyUsers]);
  
  const effectiveRadius = Math.min(containerSize.width * 0.8, containerSize.height * 0.8) * ORBIT_RADIUS_FACTOR;

  const handleScroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -containerSize.width / 2 : containerSize.width / 2;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };


  if (locationLoading && !currentUser) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin mb-6"></div>
        <p className="text-lg font-semibold text-muted-foreground">Finding BUMPs nearby...</p>
      </div>
    );
  }
  
  if (!currentUser) {
     return (
      <div className="flex flex-col items-center justify-center h-full text-center p-4">
        <UserPlus className="w-16 h-16 text-muted-foreground/50 mb-4" />
        <p className="text-lg font-semibold text-muted-foreground">Please log in to see nearby users.</p>
      </div>
    );
  }


  return (
    <div className="flex flex-col h-full w-full items-center justify-center">
      {locationError && (
         <div className="w-full p-1.5 text-xs bg-yellow-500/20 text-yellow-700 border-b border-yellow-500/30 flex items-center justify-center text-center">
            <Info className="w-3 h-3 mr-1.5 flex-shrink-0" />
            <span>{locationError}</span>
         </div>
      )}
      <div ref={containerRef} className="relative flex-grow w-full flex items-center justify-center overflow-hidden pt-2">
        {containerSize.width > 0 && currentUser && (
          <motion.div
            key="current-user-bubble"
            className="user-bubble current-user-bubble-pulse absolute z-10"
            style={{
              width: centralUserSize,
              height: centralUserSize,
              left: `calc(50% - ${centralUserSize / 2}px)`,
              top: `calc(50% - ${centralUserSize / 2}px)`,
            }}
            onClick={() => onUserSelect(currentUser)}
            title="View your profile"
          >
            <div className="avatar-container">
              <Avatar className="w-full h-full">
                <AvatarImage src={currentUser.profilePictureUrl} alt={currentUser.name} />
                <AvatarFallback className="text-xl">{getInitials(currentUser.name)}</AvatarFallback>
              </Avatar>
            </div>
          </motion.div>
        )}

        <AnimatePresence>
          {orbitingUsers.map((user, index) => {
             const angle = (index / orbitingUsers.length) * 2 * Math.PI + (Date.now() / (20000 * (1 + index*0.1)) ); // Clockwise rotation
             const x = effectiveRadius * Math.cos(angle);
             const y = effectiveRadius * Math.sin(angle);
            
            return (
              <motion.div
                key={user.id}
                className="user-bubble"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  x: `calc(50% + ${x}px - ${orbitingBubbleSize / 2}px)`,
                  y: `calc(50% + ${y}px - ${orbitingBubbleSize / 2}px)`,
                }}
                exit={{ opacity: 0, scale: 0.5 }}
                transition={{ type: "spring", stiffness: 100, damping: 15 }}
                style={{
                  width: orbitingBubbleSize,
                  height: orbitingBubbleSize,
                }}
                whileHover={{ scale: 1.1, zIndex: 20, boxShadow: "0 6px 20px hsl(var(--primary) / 0.4)" }}
                onClick={() => onUserSelect(user)}
              >
                <div className="avatar-container">
                   <Avatar className="w-full h-full">
                    <AvatarImage src={user.profilePictureUrl} alt={user.name} />
                    <AvatarFallback className="text-sm">{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
        
        {internalNearbyUsers.length === 0 && !locationLoading && currentUser && (
           <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 pointer-events-none"
          >
            <UserPlus className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-muted-foreground/80">No one's BUMPing nearby right now.</h3>
            <p className="text-sm text-muted-foreground/60 mt-1 max-w-xs">
              {usingFallback ? "Displaying users from default region." : "Try expanding your search or check back later!"}
            </p>
          </motion.div>
        )}
      </div>

      {scrollableUsers.length > 0 && (
        <div className="w-full py-2 px-1 bg-background/50 border-t border-border mt-auto shrink-0">
          <div className="flex items-center justify-between mb-1.5 px-2">
            <h3 className="text-xs font-semibold text-muted-foreground flex items-center">
              <Users className="w-3 h-3 mr-1.5"/>
              More Nearby ({scrollableUsers.length})
            </h3>
            <div className="space-x-1">
              <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => handleScroll('left')}><ChevronLeft className="h-4 w-4"/></Button>
              <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => handleScroll('right')}><ChevronRight className="h-4 w-4"/></Button>
            </div>
          </div>
          <div ref={scrollContainerRef} className="flex space-x-2 overflow-x-auto pb-1 scrollbar-thin">
            {scrollableUsers.map((user) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="flex-shrink-0 user-bubble"
                onClick={() => onUserSelect(user)}
                style={{position: 'relative', width: SCROLL_BUBBLE_SIZE, height: SCROLL_BUBBLE_SIZE}}
                whileHover={{ scale: 1.1 }}
              >
                <div className="avatar-container">
                  <Avatar className="w-full h-full">
                    <AvatarImage src={user.profilePictureUrl} alt={user.name} />
                    <AvatarFallback className="text-xs">{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default NearbyUsersBubbleView;

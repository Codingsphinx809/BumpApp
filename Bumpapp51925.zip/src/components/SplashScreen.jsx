
import React, { useEffect } from 'react';
import { motion } from 'framer-motion';

const SplashScreen = ({ onFinished }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinished();
    }, 2500); 
    return () => clearTimeout(timer);
  }, [onFinished]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 flex flex-col items-center justify-center gradient-bg z-50"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 0.2 }}
        className="p-6 bg-white/20 backdrop-blur-md rounded-full shadow-2xl mb-6"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
            <path d="M6 12c0-1.7.7-3.2 1.8-4.2"/>
            <path d="M16.2 16.2c1.1-.9 1.8-2.5 1.8-4.2"/>
            <path d="M10.2 7.8c1.1-.9 2.7-1.2 4-.8"/>
            <path d="M4.9 19.1c2.9-2.9 7-3.4 10.5-1.3"/>
            <path d="M13.8 15.2c-1.1.9 2.7 1.2-4 .8"/>
            <path d="M19.1 4.9c-2.9 2.9-7 3.4-10.5 1.3"/>
            <path d="M12 12l0 0"/>
        </svg>
      </motion.div>
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.5 }}
        className="text-5xl font-bold text-white tracking-tight"
      >
        BUMP
      </motion.h1>
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.7 }}
        className="text-lg text-white/80 mt-2"
      >
        Connecting you, instantly.
      </motion.p>
      <div className="absolute bottom-10">
        <div className="w-10 h-10 border-4 border-white/50 border-t-white rounded-full animate-spin"></div>
      </div>
    </motion.div>
  );
};

export default SplashScreen;

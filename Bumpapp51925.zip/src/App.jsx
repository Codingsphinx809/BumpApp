
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import { UserProvider, useUser } from "@/lib/user-service";
import { MessageProvider } from "@/lib/message-service";
import { LocationProvider } from "@/lib/location-service";
import SplashScreen from "@/components/SplashScreen";
import AuthScreen from "@/components/AuthScreen";
import ProfileForm from "@/components/ProfileForm";
import MainLayout from "@/components/MainLayout";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

const AppStages = {
  SPLASH: 'splash',
  AUTH: 'auth',
  CREATE_PROFILE: 'create_profile',
  EDIT_PROFILE: 'edit_profile', 
  MAIN_APP: 'main_app',
};

function AppContent() {
  const { currentUser, loading: userLoading } = useUser();
  const [currentStage, setCurrentStage] = useState(AppStages.SPLASH);

  useEffect(() => {
    if (currentStage === AppStages.SPLASH && !userLoading) {
      setCurrentStage(currentUser ? AppStages.MAIN_APP : AppStages.AUTH);
    } else if (currentStage !== AppStages.SPLASH && currentStage !== AppStages.EDIT_PROFILE && !userLoading) {
      if (currentUser && currentStage !== AppStages.MAIN_APP) {
         setCurrentStage(AppStages.MAIN_APP);
      } else if (!currentUser && currentStage === AppStages.MAIN_APP) {
         setCurrentStage(AppStages.AUTH);
      }
    }
  }, [currentUser, userLoading, currentStage]);
  
  const handleStageChange = (stage) => setCurrentStage(stage);

  if (userLoading && currentStage !== AppStages.SPLASH) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background z-[200]">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      {currentStage === AppStages.SPLASH && (
        <motion.div key="splash" exit={{ opacity: 0 }} className="h-screen w-screen fixed inset-0 z-[100]">
          <SplashScreen onFinished={() => handleStageChange(currentUser ? AppStages.MAIN_APP : AppStages.AUTH)} />
        </motion.div>
      )}

      {currentStage === AppStages.AUTH && (
        <motion.div
          key="auth"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="min-h-screen flex flex-col items-center justify-center p-4 md:p-6 gradient-bg"
        >
          <AuthScreen 
            onLoginSuccess={() => handleStageChange(AppStages.MAIN_APP)} 
            onSwitchToCreateAccount={() => handleStageChange(AppStages.CREATE_PROFILE)} 
          />
        </motion.div>
      )}
      
      {currentStage === AppStages.CREATE_PROFILE && (
         <motion.div
          key="create_profile"
          initial={{ opacity: 0, y:20 }} animate={{ opacity: 1, y:0 }} exit={{ opacity: 0, y:20 }}
          className="min-h-screen flex flex-col items-center justify-center p-4 md:p-6 bg-gradient-to-br from-background to-accent/30"
        >
          <ProfileForm onComplete={() => handleStageChange(AppStages.MAIN_APP)} isEditMode={false} />
          <Button variant="link" onClick={() => handleStageChange(AppStages.AUTH)} className="mt-6 text-sm">
            Already have an account? Login
          </Button>
        </motion.div>
      )}

      {currentStage === AppStages.EDIT_PROFILE && currentUser && (
        <motion.div
          key="edit_profile"
          initial={{ opacity: 0, y:20 }} animate={{ opacity: 1, y:0 }} exit={{ opacity: 0, y:20 }}
          className="min-h-screen flex flex-col items-center justify-center p-4 md:p-6 bg-gradient-to-br from-background to-accent/30"
        >
          <ProfileForm onComplete={() => handleStageChange(AppStages.MAIN_APP)} isEditMode={true} />
        </motion.div>
      )}

      {currentStage === AppStages.MAIN_APP && currentUser && (
        <motion.div
          key="main_app"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="h-screen flex flex-col"
        >
          <MainLayout 
            onLogout={() => handleStageChange(AppStages.AUTH)} 
            onNavigateToEditProfile={() => handleStageChange(AppStages.EDIT_PROFILE)} 
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function App() {
  return (
    <UserProvider>
      <MessageProvider>
        <LocationProvider>
          <AppContent />
          <Toaster />
        </LocationProvider>
      </MessageProvider>
    </UserProvider>
  );
}

export default App;
